public class Countdown
{
    public static void main(String[] args)
    {
        // Run this code first to see what it does. 
        // Replace the while loop with an equivalent for loop.
        for (int x = 10; x > 0; x--)
        {
            System.out.println(x);
        }
    }
}