public class Odds
{
    public static void main(String[] args)
    {
        // Your code goes here!
        for (int i = 1; i < 100; i+=2) {
            System.out.println(i);
        }
    }
}