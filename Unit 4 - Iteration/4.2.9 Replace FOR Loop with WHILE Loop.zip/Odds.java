public class Odds
{
    public static void main(String[] args)
    {
        // Run this code first to see what is does. 
        // Then replace the for loop with an equivalent while loop.
        int x = 1;
        while (x <= 10)
        {
            System.out.println(x);
            x += 2;
        }
    }
}