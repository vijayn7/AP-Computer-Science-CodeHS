public class Repeat100
{
    public static void main(String[] args)
    {
        // Your code goes here!
        for (int i = 0; i < 100; i++) {
            System.out.println("Hello Karel");
        }
    }
}