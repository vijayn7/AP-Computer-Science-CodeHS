public class MultiplicationTable
{
    public static void main(String[] args)
    {
        // Your code goes here!
        for (int i = 1; i < 11; i++) {
            System.out.println("4 * " + i + " = " + 4*i);
        }
    }
}