public class PizzaTester 
{
    public static void main(String[] args)
    {
        // Test your Pizza class here.
       Pizza t = new Pizza("Veggie", "Tomatoes, onions, olives", 12);
       Pizza q = new Pizza("Veggie", "Tomatoes, onions, olives", 12);
       Pizza a = new Pizza("Veggie", "Tomatoes, onions, olives", 12);
       System.out.println(t);
       System.out.println(q);
       System.out.println(a);
    }
}