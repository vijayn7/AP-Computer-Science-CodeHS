public class FlowerTester
{
    public static void main(String[] args)
    {
       Flower foxglove = new Flower("Foxglove", "Red", "Digitalis", "obscura");
        System.out.println(foxglove);
    }
}