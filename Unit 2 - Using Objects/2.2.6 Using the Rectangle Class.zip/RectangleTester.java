public class RectangleTester 
{
    public static void main(String[] args)
    {
        // Create a rectangle with width 5 and height 12
        Rectangle room = new Rectangle(5, 12);
        // Then print it out
        System.out.println(room);
    }
}